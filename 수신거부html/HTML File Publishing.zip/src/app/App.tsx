import MailForm from "../imports/MailForm";

export default function App() {
  return (
    <MailForm />
  );
}