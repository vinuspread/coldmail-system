
  # HTML File Publishing

  This is a code bundle for HTML File Publishing. The original project is available at https://www.figma.com/design/0kLi4uNZV42jVKgFfworc3/HTML-File-Publishing.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  